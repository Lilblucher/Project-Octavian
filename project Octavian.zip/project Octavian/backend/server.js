const express = require('express');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors()); 
app.use(express.json()); 

app.post('/log-download', (req, res) => {
    const { vpn, version, timestamp } = req.body;
    
    if (!vpn || !version) {
        return res.status(400).send("Missing data");
    }

    const logEntry = `[${timestamp}] DOWNLOADED: ${vpn} | Folder: ${version}\n`;

    fs.appendFile('downloads_log.txt', logEntry, (err) => {
        if (err) {
            console.error("❌ Failed to write log:", err);
            return res.status(500).send("Server Error");
        }
        console.log(`✅ Logged: ${vpn} (${version})`);
        res.status(200).send("Logged successfully");
    });
});

app.listen(PORT, () => {
    console.log(`🚀 Tracking server running on http://localhost:${PORT}`);
});