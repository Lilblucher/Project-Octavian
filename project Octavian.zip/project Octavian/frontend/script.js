const btn = document.getElementById('ad-trigger');
const select = document.getElementById('vpn-selector');
const historyList = document.getElementById('history-list');

let count = 0; 
let adsWatched = 0;
const MAX_LIMIT = 10;

// Mapping to directory setup matching your image structures
const configDatabase = {
    "Socksip": {
        folder: "configs/socksip",
        file: "socksip.sip",
        versions: 2 // Has v1 and v2 directories
    },
    "Http Custom": {
        folder: "configs/http-custom",
        file: "httpcustom.hc",
        versions: 1 // Defaults to v1/httpcustom.hc
    },
    "ZiVPN": {
        folder: "configs/zivpn",
        file: "zivpn.ziv",
        versions: 1 // Defaults to v1/zivpn.ziv
    }
};

select.onchange = () => {
    document.getElementById('proto-label').innerText = select.value;
    document.getElementById('res-title').innerText = select.value.toUpperCase();
    adsWatched = 0;
    btn.innerText = `▶ Watch Ad (0/3)`;
};

btn.onclick = () => {
    if (count >= MAX_LIMIT) {
        alert("Daily download limit reached! Try again tomorrow.");
        return;
    }

    btn.innerText = "⏳ Loading Ad...";
    btn.disabled = true;

    // Optional Adsterra redirect window injection point:
    // window.open('https://your-adsterra-directlink.com', '_blank');

    setTimeout(() => {
        adsWatched++;
        
        if (adsWatched < 3) {
            btn.innerText = `▶ Watch Ad (${adsWatched}/3)`;
            btn.disabled = false;
            document.getElementById('status-text').innerText = `Progress: ${adsWatched}/3 ads viewed.`;
        } else {
            const selection = configDatabase[select.value];
            const randomVer = Math.floor(Math.random() * selection.versions) + 1;
            const filePath = `${selection.folder}/v${randomVer}/${selection.file}`;

            // Check if file is physically present before executing metrics update
            fetch(filePath, { method: 'HEAD' })
                .then(res => {
                    if (res.ok) {
                        startDownload(filePath, select.value, `v${randomVer}`);
                    } else {
                        showError();
                    }
                })
                .catch(() => showError())
                .finally(() => {
                    btn.innerText = `▶ Watch Ad (0/3)`;
                    btn.disabled = false;
                    adsWatched = 0;
                });
        }
    }, 1500); // 1.5 seconds simulated viewing duration
};

function startDownload(path, vpn, ver) {
    const link = document.createElement('a');
    link.href = path;
    link.download = ""; 
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    count++;
    
    // UI Engine Metric Sync
    document.getElementById('total-val').innerText = count;
    document.getElementById('limit-num').innerText = MAX_LIMIT - count;
    document.getElementById('quota-text').innerText = MAX_LIMIT - count;
    document.getElementById('used-val').innerText = count + " used";
    document.getElementById('bar').style.width = ((MAX_LIMIT - count) / MAX_LIMIT * 100) + "%";
    document.getElementById('status-text').innerHTML = `<span style="color:#22c55e; font-weight:bold;">Downloaded ${vpn} (${ver})</span>`;

    // History log list injector
    if (document.getElementById('empty-history')) document.getElementById('empty-history').remove();
    const item = document.createElement('div');
    item.className = 'glass-strong';
    item.style.padding = '15px 20px';
    item.style.display = 'flex';
    item.style.justifyContent = 'space-between';
    item.style.color = "white";
    item.innerHTML = `<span>Config Extracted</span><span style="color:#a78bfa; font-size:0.75rem; font-weight:bold;">${vpn} (${ver})</span>`;
    historyList.prepend(item);

    // Relay endpoint communication to backend server.js
    fetch('http://localhost:3000/log-download', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ vpn: vpn, version: ver, timestamp: new Date().toLocaleString() })
    }).catch(e => console.log("Backend telemetry server offline. Local operational loop succeeded."));
}

function showError() { document.getElementById('contact-modal').style.display = 'flex'; }
function closeModal() { document.getElementById('contact-modal').style.display = 'none'; }